const http = require('http');
const url = require("url");
const fs = require("fs");
const { parse } = require('querystring');
   const form1 = `<!doctype html>
<html>
  <head>
        <meta charset="utf8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <title></title>
        <style type="text/css">
             .titles {
             	margin: 0;
             	padding: 0;
             	border: none;
             	width: 100%;
             	height: 150px;
             	background-color: white;
             	font-weight:light;
             	position: static;
             }
           
           .intitles {
           	 margin:0;
           	 padding:0.5% 0.2%;
           	 border:none;
           	 width:auto;
           	 height:auto;
           	 
           }
           .adbt {
           	
           	width:50%;
           	height:auto;
           	margin:0;
           	padding:0;
           	border:none;
           	float:left;
           	clear:left;
           }
           .adbtbcn {
           	
           	width:50%;
           	height:auto;
           	margin:0;
           	padding:0;
           	float:right;
           	clear:right;
           	text-align:right;
           }
           .adbth {
           	float:none;
           	clear:both;
           	width:100%;
           	height:auto;
           	margin:0 0 0  0;
           	padding:0.5% 0 0 0;
           	border:none;
           }
          
           fieldset {
           		  width:96%;
           	margin:0;
           	padding:0 2%;
           	height:2900px;
           }
            form {
            	  background-color: ;
            	  width:100%;
           	height:auto;
           	margin:0;
           	padding:0;
           	border:none;
            	 }
            
            .schedules {
            	
            	border: 2px solid red;
            	height: 900px;
            	width: auto;
            	background-color: skyblue;
            	margin: 0;
            	padding: 0;
            }
            .headnga {
            	display: block;
            	height: 50px;
            	width: 30%;
            	float: none;
            	clear: both;
            	
            }
            
            
            .firstaa {
            	height: 50px;
            	display: block;
            	margin: 0;
            	padding: 0;
            	background-color: pink;
            }
            
            
            #bbtdbfsa {
            	width: 25%;
            	float: left;
            	clear: left;
            	
            }
            #nptbdfsa {
            width: 25%;
            float: left;
            clear: none;	
            text-align: center;	
            }
            #cntdbfsa {
            	width: 25%;
            	float: left;
            	clear: none;
            	text-align: center;
            }
            #pntdbfsa {
            	width: 25%;
            	float: right;
            	clear: right;
            	text-align: right;
            }
            
            
            .firstas {
            	display: block;
            	background-color: white;
            	height: 100%;
            }
            
            
            
           .firstrt, .first, .firstbtn {
           	display:block;
           	height:50px;
           	background-color:pink;
           	margin:0;
           	padding:0;
           }
           .firsta {
           	display:block;
           	background-color: white;
           	height:100%;
           }
           label {
           display:block;
           	margin:0;
           	padding:0;
           	border:none;
           	width: auto;
           } 
           #rtdbfs {
           	float:none;
           	clear:both;
           	width:100%;
           	margin:0;
           	padding:0;
           	border:none;
           	
           }
           #bbtdbfs {
           	width:16.5%;
           	float:left;
           	clear:left;
           	
           }
           
           #nptbdfs {
           	width:16.5%;
           	float:left;
           	clear:none;
           	text-align:center;
           }
           #cntdbfs {
           	width:16.5%;
           	float:left;
           	clear:none;
           	text-align:center;
           }
           #pntdbfs {
           	width:17%;
           	float:left;
           	clear:none;
           	text-align:center;
           }
           #lstdbfs {
           	width:16.5%;
           	float:right;
           	clear:right;
           	text-align:right;
           }
           #ubtntdbfs {
           	float:none;
           	clear:both;
           	width:100%;
           	margin:5px 0 0 0;
           	padding:0;
           	border:none;
           	text-align:right;
           }
           #rtdbss {
           	margin:0 0px;
           	width:auto;
           	padding:0 0px;
           }
           #rtdbi {
           	width:50%;
           	
           }
           input[type=text] {
           	width:auto;
           }
           
           
        </style>
        
        <script>
 window.onload=function() {
 var elems = document.getElementsByTagName("input");
 // capture submit to store storage

 document.getElementById("inputform").onsubmit=processField;
 for (var i = 0; i < elems.length; i++) {
 if (elems[i].type == "text") {
 // restore
 var value = localStorage.getItem(elems[i].id);
 if (value) elems[i].value = value;
 // change event
 elems[i].onchange=processField;
 }
 }
 }
 // store field values
 function processField() {
 localStorage.setItem(window.location.href,"true");
 localStorage.setItem(this.id, this.value);
 }
 // clear individual fields
 function clearStored() {
 var elems = document.getElementsByTagName("input");
 for (var i = 0; i < elems.length; i++) {
 if (elems[i].type == "text") {
 localStorage.removeItem(elems[i].id);
 }
 }
 }
</script>
    </head>
    <body>
        <div class="titles">
        	<div class="intitles">
        		<h1 class="adbt">Admin dash board:</h1>
        		<h2 class="adbtbcn">Kasese Bus Company Limited</h2>
        		<h3 class="adbth">Travel status update Cpanel:</h3>
        	</div>
        </div>
        <fieldset>
        
          <form action="/" method="post" id="inputform">
          <p class="schedules">
            <span class="headnga"><u>Shedule:</u></span>
            
            <span class="firstaa" id="bbtdbfsa"><span class="firstas" id="bbtdbssa"><label for="one">Time:</label> <input type="text" name="time" id="one"/> </span></span>
            <span class="firstaa" id="nptbdfsa"><span class="firstas" id="nptbdssa"><label for="nptbdai">Route:</label> <input type="text" name="route" id="two"/> </span></span>
            <span class="firstaa" id="cntdbfsa"><span class="firstas" id="cntdbssa"><label for="cntdbai">Brand:</label> <input type="text" name="brand" id="three"/> </span></span>
            <span class="firstaa" id="pntdbfsa"><span class="firstas" id="pntdbssa"><label for="pntdbai">Opinion:</label> <input type="text" name="opinion" id="four"/> </span></span>
            <span class="firstaa" id="bbtdbfsa"><span class="firstas" id="bbtdbssa"><label for="bbtdbai"></label> <input type="text" name="firsttime" id="five"/> </span></span>
            <span class="firstaa" id="nptbdfsa"><span class="firstas" id="nptbdssa"><label for="nptbdai"></label> <input type="text" name="firstroute" id="six"/> </span></span>
            <span class="firstaa" id="cntdbfsa"><span class="firstas" id="cntdbssa"><label for="cntdbai"></label> <input type="text" name="firstbrand" id="seven"/> </span></span>
            <span class="firstaa" id="pntdbfsa"><span class="firstas" id="pntdbssa"><label for="pntdbai"></label> <input type="text" name="firstopinion" id="eight"/> </span></span>
            
            <span class="firstaa" id="bbtdbfsa"><span class="firstas" id="bbtdbssa"><label for="bbtdbai"></label> <input type="text" name="secondtime" id="nine"/> </span></span>
            <span class="firstaa" id="nptbdfsa"><span class="firstas" id="nptbdssa"><label for="nptbdai"></label> <input type="text" name="secondroute" id="ten"/> </span></span>
            <span class="firstaa" id="cntdbfsa"><span class="firstas" id="cntdbssa"><label for="cntdbai"></label> <input type="text" name="secondbrand" id="eleven"/> </span></span>
            <span class="firstaa" id="pntdbfsa"><span class="firstas" id="pntdbssa"><label for="pntdbai"></label> <input type="text" name="secondopinion" id="twelve"/> </span></span>
        
            <span class="firstaa" id="bbtdbfsa"><span class="firstas" id="bbtdbssa"><label for="bbtdbai"></label> <input type="text" name="thirdtime" id="thirteen"/> </span></span>
            <span class="firstaa" id="nptbdfsa"><span class="firstas" id="nptbdssa"><label for="nptbdai"></label> <input type="text" name="thirdroute" id="fourteen"/> </span></span>
            <span class="firstaa" id="cntdbfsa"><span class="firstas" id="cntdbssa"><label for="cntdbai"></label> <input type="text" name="thirdbrand" id="fifteen"/> </span></span>
            <span class="firstaa" id="pntdbfsa"><span class="firstas" id="pntdbssa"><label for="pntdbai"></label> <input type="text" name="thirdopinion" id="sixteen"/> </span></span>
        
            <span class="firstaa" id="bbtdbfsa"><span class="firstas" id="bbtdbssa"><label for="bbtdbai"></label> <input type="text" name="fourthtime" id="seventeen"/> </span></span>
            <span class="firstaa" id="nptbdfsa"><span class="firstas" id="nptbdssa"><label for="nptbdai"></label> <input type="text" name="fourthroute" id="eighteen"/> </span></span>
            <span class="firstaa" id="cntdbfsa"><span class="firstas" id="cntdbssa"><label for="cntdbai"></label> <input type="text" name="fourthbrand" id="nineteen"/> </span></span>
            <span class="firstaa" id="pntdbfsa"><span class="firstas" id="pntdbssa"><label for="pntdbai"></label> <input type="text" name="fourthopinion" id="twenty"/> </span></span>
            
            <span class="firstaa" id="bbtdbfsa"><span class="firstas" id="bbtdbssa"><label for="bbtdbai"></label> <input type="text" name="fifthtime" id="twentyone"/> </span></span>
            <span class="firstaa" id="nptbdfsa"><span class="firstas" id="nptbdssa"><label for="nptbdai"></label> <input type="text" name="fifthroute" id="twentytwo"/> </span></span>
            <span class="firstaa" id="cntdbfsa"><span class="firstas" id="cntdbssa"><label for="cntdbai"></label> <input type="text" name="fifthbrand" id="twentythree"/> </span></span>
            <span class="firstaa" id="pntdbfsa"><span class="firstas" id="pntdbssa"><label for="pntdbai"></label> <input type="text" name="fifthopinion" id="twentyfour"/> </span></span>
            
            <span class="firstaa" id="bbtdbfsa"><span class="firstas" id="bbtdbssa"><label for="bbtdbai"></label> <input type="text" name="sixthtime" id="twentyfive"/> </span></span>
            <span class="firstaa" id="nptbdfsa"><span class="firstas" id="nptbdssa"><label for="nptbdai"></label> <input type="text" name="sixthroute" id="twentysix"/> </span></span>
            <span class="firstaa" id="cntdbfsa"><span class="firstas" id="cntdbssa"><label for="cntdbai"></label> <input type="text" name="sixthbrand" id="twentyseven"/> </span></span>
            <span class="firstaa" id="pntdbfsa"><span class="firstas" id="pntdbssa"><label for="pntdbai"></label> <input type="text" name="sixthopinion" id="twentyeight"/> </span></span>
            
            <span class="firstaa" id="bbtdbfsa"><span class="firstas" id="bbtdbssa"><label for="bbtdbai"></label> <input type="text" name="seventhtime" id="twentynine"/> </span></span>
            <span class="firstaa" id="nptbdfsa"><span class="firstas" id="nptbdssa"><label for="nptbdai"></label> <input type="text" name="seventhroute" id="thirty"/> </span></span>
            <span class="firstaa" id="cntdbfsa"><span class="firstas" id="cntdbssa"><label for="cntdbai"></label> <input type="text" name="seventhbrand" id="thirtyone"/> </span></span>
            <span class="firstaa" id="pntdbfsa"><span class="firstas" id="pntdbssa"><label for="pntdbai"></label> <input type="text" name="seventhopinion" id="thirtytwo"/> </span></span>
            
            <span class="firstaa" id="bbtdbfsa"><span class="firstas" id="bbtdbssa"><label for="bbtdbai"></label> <input type="text" name="eighthtime" id="thirtythree"/> </span></span>
            <span class="firstaa" id="nptbdfsa"><span class="firstas" id="nptbdssa"><label for="nptbdai"></label> <input type="text" name="eighthroute" id="thirtyfour"/> </span></span>
            <span class="firstaa" id="cntdbfsa"><span class="firstas" id="cntdbssa"><label for="cntdbai"></label> <input type="text" name="eighthbrand" id="thirtyfive"/> </span></span>
            <span class="firstaa" id="pntdbfsa"><span class="firstas" id="pntdbssa"><label for="pntdbai"></label> <input type="text" name="eighthopinion" id="thirtysix"/> </span></span>
        
            <span class="firstaa" id="bbtdbfsa"><span class="firstas" id="bbtdbssa"><label for="bbtdbai"></label> <input type="text" name="ninethtime" id="thirtyseven"/> </span></span>
            <span class="firstaa" id="nptbdfsa"><span class="firstas" id="nptbdssa"><label for="nptbdai"></label> <input type="text" name="ninethroute" id="thirtyeight"/> </span></span>
            <span class="firstaa" id="cntdbfsa"><span class="firstas" id="cntdbssa"><label for="cntdbai"></label> <input type="text" name="ninethbrand" id="thirtynine"/> </span></span>
            <span class="firstaa" id="pntdbfsa"><span class="firstas" id="pntdbssa"><label for="pntdbai"></label> <input type="text" name="ninethopinion" id="fourty"/> </span></span>
            
          </p>
          
          <p class="schedules">
            <span class="headngb"><u>Already Moving Buses:</u></span>
            <span class="firstrt" id="rtdbfs"><span class="firsta" id="rtdbss"><label for="rtdbi">Route:</label> <input type="text" name="rtdba" id="fourtyone" style="width: 31%;"/> </span></span>
            <span class="first" id="bbtdbfs"><span class="firsta" id="bbtdbss"><label for="bbtdbi">1. Bus Brand:</label> <input type="text" name="bbtdba" id="fourtytwo"/> </span></span>
            <span class="first" id="nptbdfs"><span class="firsta" id="nptbdss"><label for="nptbdi">Number plate:</label> <input type="text" name="nptdba" id="fourtythree"/> </span></span>
            <span class="first" id="cntdbfs"><span class="firsta" id="cntdbss"><label for="cntdbi">Conductor name:</label> <input type="text" name="cntdba" id="fourtyfour"/> </span></span>
            <span class="first" id="pntdbfs"><span class="firsta" id="pntdbss"><label for="pntdbi">Phone number:</label> <input type="text" name="pntdba" id="fourtyfive"/> </span></span>
            <span class="first" id="pntdbfs"><span class="firsta" id="pntdbss"><label for="pntdbi">Registered Location ID:</label> <input type="text" name="Location" id="fourtysix"/> </span></span>
            <span class="first" id="lstdbfs"><span class="firsta" id="lstdbss"><label for="lstdbi">Leaving status:</label> <input type="text" name="lstdba" id="fourtyseven"/> </span></span>
        </p>
          
          
          <p class="schedules" style="background-color:mintcream;">
             <span class="headngb" style="display: block; width: 100%;"><u>Payment Methods:</u></span>
             <span class="headngb" style="display: block; width: 100%;"><u>a. Paypal:</u></span>
              <span class="first" id="bbtdbfs" style="width: 40%;"><span class="firsta" id="bbtdbss" style="display: block; width: 100%;"><label for="bbtdbi" style="display: block; width: 100%;"> Account names:</label> <input type="text" name="paypalaccname" id="fourtyeight" style="display: block; width: 98%;"/> </span></span>         	
           	<span class="first" id="lstdbfs" style="width: 40%; background-color: red;"><span class="firsta" id="lstdbss" style="width: 100%; display: block;"><label for="lstdbi" style="display:block; width: 100%; text-align: left;">Account URL:</label> <input type="text" name="paypalurl" id="fourtynine" style="display: block; width: 98%;"/> </span></span>
           	<br/><br/>
           	 <span class="first" id="bbtdbfs" style="width: 40%; height: 100px;"><span class="firsta" id="bbtdbss" style="display: block; width: 100%;"><span class="first" id="bbtdbfs" style="width: 40%;"><span class="firsta" id="bbtdbss" style="display: block; width: 100%;"><label for="bbtdbi" style="display: block; width: 100%;"> Greeting:</label> <input type="text" name="paypalgreeting" id="fifty" style="display: block; width: 98%; height: 35px;"/> </span></span>            <span class="first" id="lstdbfs" style="width: 40%; background-color: red;"><span class="firsta" id="lstdbss" style="width: 100%; display: block;"><label for="lstdbi" style="display:block; width: 100%; text-align: left;">Client:</label> <input type="text" name="paypalclient" id="fiftyone" style="display: block; width: 96%; height: 35px;"/> </span></span>
 </span></span>         	
           	<span class="first" id="lstdbfs" style="width: 40%; background-color: red;"><span class="firsta" id="lstdbss" style="width: 100%; display: block;"><label for="lstdbi" style="display:block; width: 100%; text-align: left;">Note:</label> <input type="text" name="paypalnote" id="fiftytwo" style="display: block; width: 98%; height: 30px;"/> </span></span>
           	<span class="first" id="lstdbfs" style="width: 40%; background-color: red; height: 60px; margin-top: 8px;"><span class="firsta" id="lstdbss" style="width: 100%; display: block;"><label for="lstdbi" style="display:block; width: 100%; text-align: left;">Info:</label> <input type="text" name="paypalinfo" id="fiftythree" style="display: block; width: 98%; height: 30px;"> </span></span>
           	<br/><br/>
           	
           	   <span class="headngb" style="display: block; width: 100%; clear:both; float: none;"><u>b.Pioneer:</u></span>
              <span class="first" id="bbtdbfs" style="width: 40%;"><span class="firsta" id="bbtdbss" style="display: block; width: 100%;"><label for="bbtdbi" style="display: block; width: 100%;"> Account names:</label> <input type="text" name="pioneeraccname" id="fiftyfour" style="display: block; width: 98%;"/> </span></span>         	
           	<span class="first" id="lstdbfs" style="width: 40%; background-color: red;"><span class="firsta" id="lstdbss" style="width: 100%; display: block;"><label for="lstdbi" style="display:block; width: 100%; text-align: left;">Account URL:</label> <input type="text" name="pioneerurl" id="fiftyfive" style="display: block; width: 98%;"/> </span></span>
           	<br/><br/>
           	
           	<span class="first" id="bbtdbfs" style="width: 40%; height: 100px;"><span class="firsta" id="bbtdbss" style="display: block; width: 100%;"><span class="first" id="bbtdbfs" style="width: 40%;"><span class="firsta" id="bbtdbss" style="display: block; width: 100%;"><label for="bbtdbi" style="display: block; width: 100%;"> Greeting:</label> <input type="text" name="pioneergreeting" id="fiftysix" style="display: block; width: 98%; height: 35px;"/> </span></span>            <span class="first" id="lstdbfs" style="width: 40%; background-color: red;"><span class="firsta" id="lstdbss" style="width: 100%; display: block;"><label for="lstdbi" style="display:block; width: 100%; text-align: left;">Client:</label> <input type="text" name="pioneerclient" id="fiftyseven" style="display: block; width: 96%; height: 35px;"/> </span></span>
 </span></span>         	
           	<span class="first" id="lstdbfs" style="width: 40%; background-color: red;"><span class="firsta" id="lstdbss" style="width: 100%; display: block;"><label for="lstdbi" style="display:block; width: 100%; text-align: left;">Note:</label> <input type="text" name="pioneernote" id="fiftyeight" style="display: block; width: 98%; height: 30px;"/></span></span>
           <br/><br/>
           	<span class="first" id="lstdbfs" style="width: 40%; background-color: red; height: 60px; margin-top: 8px;"><span class="firsta" id="lstdbss" style="width: 100%; display: block;"><label for="lstdbi" style="display:block; width: 100%; text-align: left;">info:</label> <input type="text" name="pioneerinfo" id="fiftynine" style="display: block; width: 98%; height: 30px;"/> </span></span>
           	<br/><br/>
           	
           	   <span class="headngb" style="display: block; width: 100%; clear:both; float: none;"><u>c.Mobile Money:</u></span>
             <span class="headngb" style="display: block; width: 100%; clear:both; float: none;"><u>i. MTN:</u></span>
              <span class="first" id="bbtdbfs" style="width: 40%;"><span class="firsta" id="bbtdbss" style="display: block; width: 100%;"><label for="bbtdbi" style="display: block; width: 100%;"> Account names:</label> <input type="text" name="mmmaccname" id="sixty" style="display: block; width: 98%;"/> </span></span>         	
           	<span class="first" id="lstdbfs" style="width: 40%; background-color: red;"><span class="firsta" id="lstdbss" style="width: 100%; display: block;"><label for="lstdbi" style="display:block; width: 100%; text-align: left;">Account Phone number:</label> <input type="text" name="mmmaccphonenumber" id="sixtyone" style="display: block; width: 98%;"/> </span></span> 
           <br/><br/>
           
          
           	
           	 
      <span class="headngb" style="display: block; width: 100%; clear:both; float: none;"><u>Entry Codes:</u></span>
       <span class="first" id="bbtdbfs" style="width: 6%;"><span class="firsta" id="bbtdbss" style="display: block; width: 100%;"><label for="sixtytwo" style="display: block; width: 100%;"> 1</label> <input type="text" name="mcodeone" id="sixtythree" style="display: block; width: 98%;"/> </span></span> 
        <span class="first" id="cntdbfs" style="width: 6%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">2</label> <input type="text" name="mcodetwo" id="sixtyfour"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 6%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">3</label> <input type="text" name="mcodethree" id="sixtyfive"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 6%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">4</label> <input type="text" name="mcodefour" id="sixtysix"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 6%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">5</label> <input type="text" name="mcodefive" id="sixtyseven"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 6%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">6</label> <input type="text" name="mcodesix" id="sixtyeight"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 6%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">7</label> <input type="text" name="mcodeseven" id="sixtynine"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 6%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">8</label> <input type="text" name="mcodeeight" id="seventy"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 6%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">9</label> <input type="text" name="mcodenine" id="seventyone"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 16%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">10</label> <input type="text" name="mcodeten" id="seventytwo"  style="display: block; width: 94%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 6%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">11</label> <input type="text" name="mcodeeleven" id="seventythree"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 6%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">12</label> <input type="text" name="mcodetwelve" id="seventyfour"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 6%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">13</label> <input type="text" name="mcodethirteen" id="seventyfive"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 6%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">14</label> <input type="text" name="mcodefourteen" id="seventysix"  style="display: block; width: 84%;"/> </span></span>   	
        <span class="first" id="lstdbfs" style="width: 6%; background-color: red;"><span class="firsta" id="lstdbss" style="width: 100%; display: block;"><label for="lstdbi" style="display:block; width: 100%; text-align: left;">15</label> <input type="text" name="mcodefifteen" id="seventyseven" style="display: block; width: 90%;"/> </span></span>
           
           
           <span class="headngb" style="display: block; width: 100%; clear:both; float: none;"><u>ii. AIRTEL:</u></span>
              <span class="first" id="bbtdbfs" style="width: 40%;"><span class="firsta" id="bbtdbss" style="display: block; width: 100%;"><label for="bbtdbi" style="display: block; width: 100%;"> Account names:</label> <input type="text" name="ammaccname" id="seventyeight" style="display: block; width: 98%;"/> </span></span>         	
           	<span class="first" id="lstdbfs" style="width: 40%; background-color: red;"><span class="firsta" id="lstdbss" style="width: 100%; display: block;"><label for="lstdbi" style="display:block; width: 100%; text-align: left;">Account Phone number:</label> <input type="text" name="ammphonenumber" id="seventynine" style="display: block; width: 98%;"/> </span></span> 
           	
      <br/><br/>
      
        	
           	
           	
      <span class="headngb" style="display: block; width: 100%; clear:both; float: none;"><u>Entry Codes:</u></span>
       <span class="first" id="bbtdbfs" style="width: 7%;"><span class="firsta" id="bbtdbss" style="display: block; width: 100%;"><label for="bbtdbi" style="display: block; width: 100%;"> 1</label> <input type="text" name="acodeone" id="eighty" style="display: block; width: 98%;"/> </span></span> 
        <span class="first" id="cntdbfs" style="width: 7%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">2</label> <input type="text" name="acodetwo" id="eightyone"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 7%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">3</label> <input type="text" name="acodethree" id="eightytwo"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 7%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">4</label> <input type="text" name="acodefour" id="eightythree"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 7%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">5</label> <input type="text" name="acodefive" id="eightyfour"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 7%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">6</label> <input type="text" name="acodesix" id="eightyfive"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 7%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">7</label> <input type="text" name="acodeseven" id="eightysix"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 7%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">8</label> <input type="text" name="acodeeight" id="eightyseven"  style="display: block; width: 94%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 7%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">9</label> <input type="text" name="acodenine" id="eightyeight"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 16%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">10</label> <input type="text" name="acodeten" id="eightynine"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 7%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">11</label> <input type="text" name="acodeeleven" id="ninety"  style="display: block; width: 96%;"/> </span></span>   	
        <span class="first" id="cntdbfs" style="width: 7%; background-color: red;"><span class="firsta" id="cntdbss" style="width: 100%; display: block;"><label for="cntdbi" style="display:block; width: 100%; text-align: left;">12</label> <input type="text" name="acodetwelve" id="ninetyone"  style="display: block; width: 84%;"/> </span></span>   	
        <span class="first" id="lstdbfs" style="width: 7%; background-color: red;"><span class="firsta" id="lstdbss" style="width: 100%; display: block;"><label for="lstdbi" style="display:block; width: 100%; text-align: left;">13</label> <input type="text" name="acodethirteen" id="ninetytwo" style="display: block; width: 90%;"/> </span></span>
           <br/><br/>
           
            <span class="first" id="bbtdbfs" style="width: 40%; height: 70px;"><span class="firsta" id="bbtdbss" style="display: block; width: 100%;"><span class="first" id="bbtdbfs" style="width: 40%;"><span class="firsta" id="bbtdbss" style="display: block; width: 100%;"><label for="bbtdbi" style="display: block; width: 100%;"> Greeting:</label> <input type="text" name="mobilemoneygreeting" id="ninetythree" style="display: block; width: 98%; height: 35px;"/> </span></span>            <span class="first" id="lstdbfs" style="width: 40%; background-color: red;"><span class="firsta" id="lstdbss" style="width: 100%; display: block;"><label for="lstdbi" style="display:block; width: 100%; text-align: left;">Client:</label> <input type="text" name="mobilemoneyclient" id="ninetyfour" style="display: block; width: 96%; height: 35px;"/> </span></span>
 </span></span>         	
           	<span class="first" id="lstdbfs" style="width: 40%; background-color: red;"><span class="firsta" id="lstdbss" style="width: 100%; display: block;"><label for="lstdbi" style="display:block; width: 100%; text-align: left;">Note:</label> <input type="text" name="mobilemoneynote" id="ninetyfive" style="display: block; width: 98%; height: 30px;"> </span></span>
           <span class="first" id="lstdbfs" style="width: 40%; background-color: red; height: 60px; margin-top: 8px;"><span class="firsta" id="lstdbss" style="width: 100%; display: block;"><label for="lstdbi" style="display:block; width: 100%; text-align: left;">Info:</label> <input type="text" name="mobilemoneyinfo" id="ninetysix" style="display: block; width: 98%; height: 30px;"/> </span></span>	
           
           <span class="first" id="bbtdbfs" style="width: 40%; height: 100px;"><span class="firsta" id="bbtdbss" style="display: block; width: 100%;"><span class="first" id="bbtdbfs" style="width: 40%;"><span class="firsta" id="bbtdbss" style="display: block; width: 100%;"><label for="bbtdbi" style="display: none; width: 100%;"> </label> <input type="text" name="mobilemoneygreeting" value="Reciept :" id="ninetyseven" style="display: block; width: 98%; height: 35px; border: none;" disabled/> </span></span>            <span class="first" id="lstdbfs" style="width: 40%; background-color: red;"><span class="firsta" id="lstdbss" style="width: 100%; display: block;"><label for="lstdbi" style="display:none; width: 100%; text-align: left;"> </label> <button class="reciept" name="adminreciept" id="reciept" style="display: block; width: 96%; height: 35px;"> <a href="http://localhost:3010/" id="" style="">Include!</a></button></span></span>
 </span></span>  
           
           
           </p>
             
           
           
            <span class="firstbtn" id="ubtntdbfs"><span class="firsta" id="ubtntdbss"> <input type="submit" value="Update!" id='ninetyeight' name="Dash Board Updated Now"/> </span></span>
          </form>
        </fieldset>
    </body>
</html>` 
const htmla = ` <!doctype html>
<html>
  <head>
        <meta charset="utf8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <title></title>
        <style type="text/css">
        
        .tittlie {
        	
        	position: relative;
        	right: 5px;
        	width:auto;
        	padding: 5px;
        	background-color: grey;
        	
        }
          h1 {
          	font-weight: lighter;
          	text-shadow: 1px 1px blue;
          	
          }
           label {
           	 display: inline-block;
           	 width: 120px;
           	
           }
           
           #adminlog {
           	 display: none;
           	
           }
           
           
           input {
           	 display: inline-block; 
           	width: 250px;
           	height: 20px;
           }
           
           input[type=submit] {
           	width: 70px;
           	margin-left: 305px;
           	height: 27px;
           	display: block; 
           	
           }
           .leftdivider {
           	height: auto;
           	padding: ;
           	width: 10%;
           	margin-top: 5px;
           }
           
        </style>
    </head>
    <body>
       <div>
        <fieldset>
         <form method="POST" action"/" id="client" class="logform">
          <p class="tittlie">RECIEPT</p>
          <h1>Journey Paid By:</h1>
          <label for="name">Name:</label><input type="text" id="name" name="clientname"><br/><br/>
          <label for="phone">Phone:</label><input type="tel" id="phone" name="clientphonenumber" required/><br/><br/>
          <label for="from">From:</label><input type="text" id="from" name="from"><br/><br/>
          <label for="to">to:</label><input type="text" id="to" name="to"><br/><br/>
          <label for="reciept">Reciept No:</label><input type="text" id="reciept" name="recieptno" placeholder="001" readonly/><br/><br/>
          <input type="submit" id="pay" value="Pay" name="Status">
         </form>
         <button class="leftdivider"><- -</button><button class="leftdivider">- -></button><button class="leftdivider"><- -</button><button class="leftdivider">- -></button><button class="leftdivider" onclick="bologyam()"><<-</button><button class="leftdivider">->></button><button class="leftdivider"><- -</button><button class="leftdivider">- -></button><button class="leftdivider"><- -</button><button class="leftdivider">- -></button>
         
         <form method="POST" action"/" id="adminlog" class="logform">
          <h1>REQUIRES PASSCODE:</h1>
          <label for="company">Company Name:</label><input type="text" id="company" name="company"/><br/><br/>
          <label for="passcode">PassCode:</label><input type="text" id="passcode" name="adminpasscode" required/><br/><br/>
          <input type="submit" id="enter" value="Enter" name="Status"/>
         </form>
         
         </fieldset>
       </div>
       
       <script>
         	
         	function bologyam() {
         		var takeme = document.getElementById('adminlog');
         		var removeit = document.getElementById('client');
         		 takeme.style.display = 'block';
         		 removeit.style.display ='none';
         	};
         	
         </script>
       
    </body>
</html> `;
  
  var htmlb = `<!doctype html>
<html>
  <head>
        <meta charset="utf8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <title></title>
        <style type="text/css">
         h1 {
          	font-weight: lighter;
          	text-shadow: 1px 1px blue;
          	
          }
           label {
           	 display: inline-block;
           	 width: 120px;
           	
           }
           input {
           	 display: inline-block; 
           	width: 250px;
           	height: 20px;
           }
           
           input[type=submit] {
           	width: 70px;
           	margin-left: 305px;
           	height: 27px;
           	display: block; 
        </style>
        <script>
 window.onload=function() {
 var elems = document.getElementsByTagName("input");
 // capture submit to store storage

 document.getElementById("adminrecieptemail").onsubmit=processField;
 for (var i = 0; i < elems.length; i++) {
 if (elems[i].type == "text") {
 // restore
 var value = localStorage.getItem(elems[i].id);
 if (value) elems[i].value = value;
 // change event
 elems[i].onchange=processField;
 }
 }
 }
 // store field values
 function processField() {
 localStorage.setItem(window.location.href,"true");
 localStorage.setItem(this.id, this.value);
 }
 // clear individual fields
 function clearStored() {
 var elems = document.getElementsByTagName("input");
 for (var i = 0; i < elems.length; i++) {
 if (elems[i].type == "text") {
 localStorage.removeItem(elems[i].id);
 }
 }
 }
</script>
    </head>
    <body>
       <div>
        <fieldset>
        <form method="POST" action"/" id="adminrecieptemail" class="logform">
          <h1>Please Update the E-mail reciept Reception E-mail Address Here</h1>
          <label for="email">E-mail:</label><input type="email" id="email" name="recieptemail" required><br/><br/>
          <input type="submit" id="update" value="Update" name="Status" />
        </form>
        
         </fieldset>
       </div>
    </body>
</html>`;

const htmlc = `<!DOCTYPE html><html lang='en'><head><meta charset='utf8'><meta name='viewport' content='width=device-width, initial-scale=1'/><title></title><script>function paypal(){const payment = document.getElementById('paylink');payment.href = 'http://www.paypal.com/pay/samuelonyait';};</script></head><body onload='showindow()'><div style='width: 100%; height: auto; margin: 0; padding: 0; border: none;'><div class='paymain' style='width: 100%; height: 600px; margin: 0; padding: 0; border: none; background-color: blue;'><div class='payinmain' style='margin: 0; padding: 0; border: none; width: 100%; height: 100%; background-color: green;'><div class='paytop' style='margin: 0; padding: 0; border: none; width: auto; height: 100%; background-color: pink;'><div class='payintop' style='width: auto; height: auto; margin: 0; padding: 0 5%; border: none; display:flex; justify-content:center; align-items:center; flex-direction:column; background-color: dodgerblue; font-family:arial; color:white; font-size: 20px;'><pre>Hello,

Dear Client;

Please The Payment You Make here is for only a single journey.

Laggage paid only after loading

This Note is By Management: higenyi transporters

<button onclick='paypal()'><a class='paylink' id='paylink' href='' style='background-color: ; padding: 0px; margin: 0; text-decoration: none;' target='_blank'>OK</a></button></pre></div></div></div></div></div></body></html>`;


  
  const htmld = `<!DOCTYPE html><html lang='en'><head><meta charset='utf8'><meta name='viewport' content='width=device-width, initial-scale=1'/><title></title><script>function paypal(){const payment = document.getElementById('paylink');payment.href = 'http://localhost:3000/';};</script></head><body onload='showindow()'><div style='width: 100%; height: auto; margin: 0; padding: 0; border: none;'><div class='paymain' style='width: 100%; height: 600px; margin: 0; padding: 0; border: none; background-color: blue;'><div class='payinmain' style='margin: 0; padding: 0; border: none; width: 100%; height: 100%; background-color: green;'><div class='paytop' style='margin: 0; padding: 0; border: none; width: auto; height: 100%; background-color: pink;'><div class='payintop' style='width: auto; height: 100%; margin: 0; padding: 0 5%; border: none; display:flex; justify-content:center; align-items:center; flex-direction:column; background-color: dodgerblue; font-family:arial; color:white; font-size: 20px;'><pre>

Your Company Payment Reciept E-mail Successfully Updated !
</pre>
<button onclick='paypal()'><a class='paylink' id='paylink' href='' style='background-color: ; padding: 0px; margin: 0; text-decoration: none;' target='_blank'>OK</a></button></div></div></div></div></div></body></html>`;


const logina = `<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>user determination</title>
		<style>
		
		body {
			
			background-color: #8bffb6;
		}
		.maincontainerfm {
				border: none;
				
				
			}
			.maincontainerfmi {
				border: 2px solid black;
				margin: 0 auto;
				background-color: red;
				width: 90%;
			}
			
			
		</style>
		
		
	</head>
	<body>
	
	
	<div class="maincontainerfm">
		<div class="laya">
			
			<h1 class="greate" style="color: #ffaa00; text-shadow: 1px 1px purple;">Greate!</h1>
			
		</div
	
		<div class="layb">
			<div class="maindeta">
				<div class="subdeta">
					<fieldset class="firstfs">
						<legend class="newuser">User pass</legend>
						<form class="newfm" method="post">
							<p class="helpn">fill in your details press enter to proceed enjoy our services if you are new , first time user or want to tour us</p>
							<label for="nemail">E-mail Adress: </label><input type="text" class="email" id="nemail" name="newUserEmail"/><br/><br/>
							<label for="nphone">Phone Number: </label><input type="text" class="phone" id="nphone" name="newUserPhoneNumber"/><br/><br/>
							<input type="submit" class="submit" id="nsubmit" value="Signin"/>
						</form>
						
					</fieldset>
				</div>
			</div>
			
			<div class="maindetb">
				<div class="subdetb">
					<fieldset class="firstfs">
						<legend class="newuser">Loggers Pass</legend>
						<form class="newfm" method="post">
							<p class="helpn">Click proceed..</p>
							<br/><br/>
							<input type="submit" class="submit" id="nsubmit" value="proceed"/>
						</form>
						
					</fieldset>
					
				</div>
			</div>
			
			
		</div>
		
		</div>
	</body>
</html>`;

const loginb = `<!doctype html>
<html>
  <head>
        <meta charset="utf8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <title></title>
        <style type="text/css">
        
        </style>
    </head>
    <body>
       <div>
        <fieldset>
         <form method="POST" action"/">
          <h1>Admin Login:</h1>
          <label for="company">Company Name:</label><input type="text" id="company" name="company"><br/><br/>
          <label for="password">Password:</label><input type="password" id="password" name="password"><br/><br/>
          <input type="submit" id="lgnbtn" value="Login" name="Status">
         </form>
         </fieldset>
       </div>
    </body>
</html>`;


const getstarted = `<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1"/>
		<title>welcome  to network</title>
		<style>
			body {
			margin-top: 0;
			margin-right: 0;
			margin-bottom: 0;
			margin-left: 0;
			background-color: red;
			padding: 0;
			border: none;
			width: 100%;
			height: 100%;	
			}
			a {
				text-decoration: none;
				margin: 0;
			padding: 0;
			border: none;
				
			}
			
			
			.mainintro {
			margin: 0;
			padding: 0;
			border: none;
			width: 100%;
			
			height: 100%;		
			background-color:green;	
			font-family: Helvetica, serif;
			}
			
			
			.introsub {
				border: none;
				margin: 0px;
				padding: 0px;
				width:100%;
				height: 657px;
				
				background-color: yellow;
			}
			.intro {
				margin: 0px;
			padding: 0px;
			border: none;
			width: 100%;
			height: 100%;
			
			background-color:pink;	
			}
			
			
			.containera {
				height: 50%;
				margin: 0;
			padding: 0;
			border: none;
			text-align: center;	
			}
			#msga {
				font-size: 20px;
				margin: 0;
				padding: 0;
				border: none; 
			}
			.msgbc {
				
				margin: 0;
			padding: 0;
			border: none;
				
			}
			
			#msgb {
				
				display: block;
				margin-top: 20px;
				padding-top: 30px;
				
				
			}
			.togo {
				display: block;	
				width: 100%;
				background-color:;
				text-align: center;
			}
			
			#tointro {
			padding-top: 10px;
			padding-bottom: 10px;
			display: inline-block;	
			background-color:orange;
			width: 100px;
			border-radius: 4px/8px;	
			box-shadow: 2px 2px 2px white;	
			}
			
			.containerb {
				height: 50%;
				margin: 0;
			padding: 0;
			border: none;
			
			}
			#paraa {
				margin: 0;
			padding: 0;
			border: none;
			height: 100%;
			background-color: yellow;
			width: 33%;
			float: left;
			clear: left;
			
				
			}
			#parab {
				margin: 0;
			padding: 0;
			border: none;
			height: 100%;
			width: 33%;
			float: left;
			clear: none;
			text-align: center;
				
			}
			#parac {
				margin: 0;
			padding: 0;
			border: none;
			height: 100%;
			width: 33%;
			float: right;
			clear: right;
			text-align: right;
			background-color: green;	
			}
			.parset {
				display: block;
				margin: 0;
			padding: 0;
			border: none;
				
			}
			#parasetid {
				padding-top: 60%;
				padding-left: 2%;
				padding-right: 2%;
				width: auto;
			}
			.btmlink {
				background-color: mintcream;
				border: 1px solid #00001f;
				
			}
			
		</style>
	</head>
	<body>
		
		<div class="mainintro">
			<div class="introsub">
				<form class="intro" id="welcomeintro" name="welcomesyou">
				  <div class="containera">
					<p id="msga">Welcome to Travofast</p>
					<span class="msgbc" id="msgb">Let's travel?</span>
					<p class="togo"><a href="./home.html" id="tointro">YES</a></p>
				   </div>
				   <div class="containerb">
				   	<p id="paraa"><span class="parset" id="parasetid"><a href="" id="linka" class="btmlink">FAQs</a></span></p><p id="parab"><span class="parset" id="parasetid"><a href="" id="linkb" class="btmlink">Help<img src="" id="helpicon"</a></span></p><p id="parac"><span class="parset" id="parasetid"><a href="" id="linkc" class="btmlink">About us</a></span></p>
				   	
				   </div>
					
				</form>
				
				
			</div>
			
			
		</div>
		
		
	</body>
</html>`;

const server = http.createServer((req, res) => {
    if (req.method === 'POST') {
        collectRequestData(req, result => {
         let parsedURL = url.parse(req.url, true);
	let path = parsedURL.path.replace(/^\/+|\/+$/g, "");
	if (path == "") {
		path = "index.html";
	} 	
            console.log(result);
            console.log(`Requested path ${path}`); 
     let filebegin = __dirname + "/publicbegin/" + path;            
	let file = __dirname + "/public/" + path;
	let filea = __dirname + "/publica/" + path;
	let fileb = __dirname + "/publicb/" + path;
	let filec = __dirname + "/publicc/" + path;
	let filed = __dirname + "/publicd/" + path;
	let filee = __dirname + "/publice/" + path;
	let filef = __dirname + "/publicf/" + path;
	let fileg = __dirname + "/publicg/" + path;
	let fileh = __dirname + "/publich/" + path;
	
	
	
	var alpha = "<div style='width: 100%; height: auto; margin: 0; padding: 0; border: none;'>";
	//already moving buses
	var a = `${result.rtdba}`;
	var b = `${result.bbtdba}`;
	var c = `${result.nptdba}`;
	var d = `${result.cntdba}`;
	var e = `${result.pntdba}`;
	var f = `${result.lstdba}`;
	
	//schedule body
	var aa = `${result.time}`;
	var bb = `${result.route}`;
	var cc = `${result.brand}`;
	var dd = `${result.opinion}`;
	
	var aaone = `${result.firsttime}`;
	var bbone = `${result.firstroute}`;
	var ccone = `${result.firstbrand}`;
	var ddone = `${result.firstopinion}`;
	
	var aatwo = `${result.secondtime}`;
	var bbtwo = `${result.secondroute}`;
	var cctwo = `${result.secondbrand}`;
	var ddtwo = `${result.secondopinion}`;
	
	var aathree = `${result.thirdtime}`;
	var bbthree = `${result.thirdroute}`;
	var ccthree = `${result.thirdbrand}`;
	var ddthree = `${result.thirdopinion}`;
	
	var aafour = `${result.fourthtime}`;
	var bbfour = `${result.fourthroute}`;
	var ccfour = `${result.fourthbrand}`;
	var ddfour = `${result.fourthopinion}`;
	
	var aafive = `${result.fifthtime}`;
	var bbfive = `${result.fifthroute}`;
	var ccfive = `${result.fifthbrand}`;
	var ddfive = `${result.fifthopinion}`;
	
	var aasix = `${result.sixthtime}`;
	var bbsix = `${result.sixthroute}`;
	var ccsix = `${result.sixthbrand}`;
	var ddsix = `${result.sixthopinion}`;
	
	var aaseven = `${result.seventhtime}`;
	var bbseven = `${result.seventhroute}`;
	var ccseven = `${result.seventhbrand}`;
	var ddseven = `${result.seventhopinion}`;
	
	var aaeight = `${result.eighthtime}`;
	var bbeight = `${result.eighthroute}`;
	var cceight = `${result.eighthbrand}`;
	var ddeight = `${result.eighthopinion}`;
	
	var aanine = `${result.ninethtime}`;
	var bbnine = `${result.ninethroute}`;
	var ccnine = `${result.ninethbrand}`;
	var ddnine = `${result.ninethopinion}`;
	
	//Payment Method
	/*Paypal*/
	var paypalaccname = ": " + `${result.paypalaccname}`;
	var paypalurl = `${result.paypalurl}`;
	var paypalgreeting = `${result.paypalgreeting}`;
	var paypalclient = `${result.paypalclient}`;
	var paypalnote = `${result.paypalnote}`;
	var paypalinfo = `${result.paypalinfo}`;
	/*Pioneer*/
	var pioneeraccname = ": " + `${result.pioneeraccname}`;
	var pioneerurl = `${result.pioneerurl}`;
	var pioneergreeting = `${result.pioneergreeting}`;
	var pioneerclient = `${result.pioneerclient}`;
	var pioneernote = `${result.pioneernote}`;
	var pioneerinfo = `${result.pioneerinfo}`;
	/*MTNMobileMoney*/
	var mmmaccname = ": " + `${result.mmmaccname}`;
	var mmmaccphonenumber = `${result.mmmaccphonenumber}`;
	var mcodeone = `${result.mcodeone}`;
	var mcodetwo = `${result.mcodetwo}`;
	var mcodethree = `${result.mcodethree}`;
	var mcodefour = `${result.mcodefour}`;
	var mcodefive = `${result.mcodefive}`;
	var mcodesix = `${result.mcodesix}`;
	var mcodeseven = `${result.mcodeseven}`;
	var mcodeeight = `${result.mcodeeight}`;
	var mcodenine = `${result.mcodenine}`;
	var mcodeten = `${result.mcodeten}`;
	var mcodeeleven = `${result.mcodeeleven}`;
	var mcodetwelve = `${result.mcodetwelve}`;
	var mcodethirteen = `${result.mcodethirteen}`;
	var mcodefourteen = `${result.mcodefourteen}`;
	var mcodefifteen = `${result.mcodefifteen}`;
	var totalmmmcodes = mcodeone + mcodetwo + mcodethree + mcodefour + mcodefive + mcodesix + mcodeseven + mcodeeight + mcodenine + mcodeten + mcodeeleven + mcodetwelve + mcodethirteen + mcodefourteen + mcodefifteen;
	/*AirtelMobileMoney*/
	var ammaccname = " : " + `${result.ammaccname}`;
	var ammaccphonenumber = `${result.ammaccphonenumber}`;
	var acodeone = `${result.acodeone}`;
	var acodetwo = `${result.acodetwo}`;
	var acodethree = `${result.acodethree}`;
	var acodefour = `${result.acodefour}`;
	var acodefive = `${result.acodefive}`;
	var acodesix = `${result.acodesix}`;
	var acodeseven = `${result.acodeseven}`;
	var acodeeight = `${result.acodeeight}`;
	var acodenine = `${result.acodenine}`;
	var acodeten = `${result.acodeten}`;
	var acodeeleven = `${result.acodeeleven}`;
	var acodetwelve = `${result.acodetwelve}`;
	var acodethirteen = `${result.acodethirteen}`;
	var totalammcodes = acodeone + acodetwo + acodethree + acodefour + acodefive + acodesix + acodeseven + acodeeight + acodenine + acodeten + acodeeleven + acodetwelve + acodethirteen;
	
	var mobilemoneygreeting = `${result.mobilemoneygreeting}`;
	var mobilemoneyclient = `${result.mobilemoneyclient}`;
	var mobilemoneynote = `${result.mobilemoneynote}`;
	var mobilemoneyinfo = `${result.mobilemoneyinfo}`;
    var mobilemoneyurl = "http://localhost:3080/";
	var paratopbegina = "<p style='margin: 0; padding: 10px 0 0 0; border: none; width: 100%; height: 80px; background-color: #0b1506; color: white; font-size: 21px; text-align: center; text-shadow: 1px 1px black;' id='paratoponea'>";
	var paratopbegin = "<p style='margin: 0; padding: 0; border: none; width: 100%; height: 90px; background-color: darkslateblue; display: none;' id='paratopone'>";
	var paratopbeginone = "<p style='margin: 0; padding: 0; border: none; width: 100%; height: 90px; background-color: darkslateblue; display: none;' id='paratoptwo'>";
	var paratopbegintwo = "<p style='margin: 0; padding: 0; border: none; width: 100%; height: 90px; background-color: darkslateblue; display: none;' id='paratopthree'>";
	var paratopbeginthree = "<p style='margin: 0; padding: 0; border: none; width: 100%; height: 90px; background-color: darkslateblue; display: none;' id='paratopfour'>";
	var paratopbeginfour = "<p style='margin: 0; padding: 0; border: none; width: 100%; height: 90px; background-color: darkslateblue; display: none;' id='paratopfive'>";
	var paratopbeginfive = "<p style='margin: 0; padding: 0; border: none; width: 100%; height: 90px; background-color: darkslateblue; display: none;' id='paratopsix'>";
	var paratopbeginsix = "<p style='margin: 0; padding: 0; border: none; width: 100%; height: 90px; background-color: darkslateblue; display: none;' id='paratopseven'>";
	var paratopbeginseven = "<p style='margin: 0; padding: 0; border: none; width: 100%; height: 90px; background-color: darkslateblue; display: none;' id='paratopeight'>";
	var paratopbegineight = "<p style='margin: 0; padding: 0; border: none; width: 100%; height: 90px; background-color: darkslateblue; display: none;' id='paratopnine'>";
	var paratopbeginnine = "<p style='margin: 0; padding: 0; border: none; width: 100%; height: 90px; background-color: darkslateblue; display: none;' id='paratopten'>";
	
	var topleftspanbegin = "<span style='margin: 0; padding: 0; border: none; display: block; float: left; clear: left; width: 20%; height: 100%; background-color: ;'>";
	var lefttopanchor = "<a href='../eschedule.html' style='margin: 15% 1%; padding: 5px; border: none; display: inline-block; text-align: right; background-color: orange; border-radius: 3px; font-size: 20px; color: white; text-decoration: none;'>";
	var toplefttext = "<===";
	var topleftspanend = "</span>";
	var topmiddlespanbegin = "<span style='margin: 0; padding: 0; border: none; display: block; float: left; clear: none; width: 60%; height: 100%; background-color: ;'>";
	var middletopanchor = "<a style='margin: 0% 0; padding: 5% 0; border: none; display: block; background-color: ; width: 100%; height: 90%; text-align: center; font-size: 21px; color: white;'>";
	var middletoptext = "We Are Currently Here !";
	var topmiddlespanend = "</span>";
	var toprightspanbegin = "<span style='margin: 0; padding: 0; border: none; display: block; float: right; clear: right; width: 20%; height: 100%; background-color: ; text-align: right; color: white;'>";
	var righttopanchor = "<a href ='../payment.html' style='margin: 15% 1%; padding: 5px; border: none; display: inline-block; text-align: right; background-color: orange; border-radius: 3px; font-size: 20px; text-decoration: none;'>";
	var righttoptext = "Board Now !";
	var toprightspanend = "</span>";
	var allanchorcloser = "</a>";
	var paratopend = "</p>";
	var starts = "<span style='display: block; float: left; clear: left; width: 25%; height: 80px; margin: 0; padding: 0;'>";
	var middles = "<span style='display: block; float: left; clear: none; width: 25%; height: 80px; text-align: center; margin: 0; padding: 0;'>";
	var stops = "<span style='display: block; float: right; clear: right; width: 25%; height: 80px; text-align: right; margin: 0; padding: 0;'>";
	var headings = "<span style='display: block; width: auto; height: 44px; padding: 15px 2px; margin: 3px; background-color: violet; font-weight: bold;'>";
	var bodys = "<span style='display: block; width: auto; height: 44px; padding: 15px 2px; margin: 3px; background-color: violet;'>";
	var closeaspns = "</span>";
	var omega = "</div>";
	var head = "Route:";
	var one = "Bus Brand:";
	var two = "Number Plate:";
	var three = "Conductor Name:";
	var four = "Phone Number";
	var five = "Leaving Status:";
	var six = "Time";
	var seven = "Opinion";
	
	
	var fn = "function "; 
	var opnb = "{";
	var clsb = "}";
	var openq = "'";
	var closeqs = "';";
	var semicolon = ";";
	var tel = "tel";
	var colon = ":";	
	var mobilemoneyurlto = tel + colon + totalmmmcodes;
	var mobilemoneyurltoa = tel + colon + totalammcodes;
	
	
	
	var name = "showindow() ";
	var nameone = "introheadoff() "; 
	var nametwo = "showtoponeoff() ";
	var namethree = "showtoptwooff() ";
	var namefour = "showtopthreeoff() ";
	var namefive = "showtopfouroff() ";
	var namesix = "showtopfiveoff() ";
	var nameseven = "showtopsixoff() ";
	var nameeight = "showtopsevenoff() ";
	var namenine = "showtopeightoff() ";
	var nameten = "showtopnineoff() ";
	var nameeleven = "showtoptenoff() ";
	var nametwoa = "showtoponeon() ";
	var namethreea = "showtoptwoon() ";
	var namefoura = "showtopthreeon() ";
	var namefivea = "showtopfouron() ";
	var namesixa = "showtopfiveon() ";
	var namesevena = "showtopsixon() ";
	var nameeighta = "showtopsevenon() ";
	var nameninea = "showtopeighton() ";
	var nametena = "showtopnineon() ";
	var nameelevena = "showtoptenon() ";
	var paypa = "paypal()";
	var paypaa = "paypala()";
	var Url = `${result.Location}`;
	
	var jss = "let url = ";
	var windowname = "let liveloc = ";
	var thename = "liveLocationWindow";
	var prop = "let properties = ";
	var theproperties = "width=1346,height=560";
	var thewindow = "let livelocationwindow = ";
	var inwindow = "window.open(url, liveloc, properties)";
	var openmove = "livelocationwindow.moveBy(0,340)";
	
	var paratoponeid = "const showoff = document.getElementById('paratoponea');";
	var paratoptwoid = "const showoff = document.getElementById('paratopone');";
	var paratopthreeid = "const showoff = document.getElementById('paratoptwo');";
	var paratopfourid = "const showoff = document.getElementById('paratopthree');";
	var paratopfiveid = "const showoff = document.getElementById('paratopfour');";
	var paratopsixid = "const showoff = document.getElementById('paratopfive');";
	var paratopsevenid = "const showoff = document.getElementById('paratopsix');";
	var paratopeightid = "const showoff = document.getElementById('paratopseven');";
	var paratopnineid = "const showoff = document.getElementById('paratopeight');";
	var paratoptenid = "const showoff = document.getElementById('paratopnine');";
	var paratopelevenid = "const showoff = document.getElementById('paratopten');";
	var pidstyleone = "showoff.style.display = 'none';";
	var pidstyleonea = "showoff.style.display = 'block';";
	
	
	
	var display = alpha + "<pre>" + "<span style='font-size: 20px;'>" + head + "\r" + "\r" + a + "\r" + "\r" + one + "\t" + "\t" + two + "\t" + "\t" + three + "\t" + "\t" + four + "\t" + "\t" + five + "\r" + "\r" + b + "\t" + "\t" + c + "\t" + "\t" + d + "\t" + "\t" + e + "\t" + "\t" + f + "</span>" + "</pre>" + omega;
	
	var displaya = "<!DOCTYPE html>" + "<html lang='en'>" + "<head>" + "<meta charset='utf8'>" + "<meta name='viewport' content='width=device-width, initial-scale=1'/>" + "<title>" + "</title>" + "<script>" + fn + name + opnb + jss + "'" + Url + "';" + windowname + "'" + thename + "';" + prop + "'" + theproperties + "';" + thewindow + inwindow +";"+ openmove + ";" + clsb + ";" + fn + nameone + opnb + paratoponeid + pidstyleone + clsb + semicolon + fn +        nametwo + opnb + paratoptwoid + pidstyleone + clsb + semicolon + fn + namethree + opnb + paratopthreeid + pidstyleone + clsb + semicolon + fn + namefour + opnb + paratopfourid + pidstyleone + clsb + semicolon + fn + namefive + opnb + paratopfiveid + pidstyleone + clsb + semicolon + fn + namesix + opnb + paratopsixid + pidstyleone + clsb + semicolon + fn + nameseven + opnb + paratopsevenid + pidstyleone + clsb + semicolon + fn + nameeight + opnb + paratopeightid + pidstyleone + clsb + semicolon + fn + namenine + opnb + paratopnineid + pidstyleone + clsb + semicolon + fn + nameten + opnb + paratoptenid + pidstyleone + clsb + semicolon + fn + nameeleven + opnb + paratopelevenid + pidstyleone + clsb + semicolon + fn + nametwoa + opnb + paratoptwoid + pidstyleonea + clsb + semicolon + fn + namethreea + opnb + paratopthreeid + pidstyleonea + clsb + semicolon + fn +       namefoura + opnb + paratopfourid + pidstyleonea + clsb + semicolon + fn + namefivea + opnb + paratopfiveid + pidstyleonea + clsb + semicolon + fn + namesixa + opnb + paratopsixid + pidstyleonea + clsb + semicolon + fn + namesevena + opnb + paratopsevenid + pidstyleonea + clsb + semicolon + fn + nameeighta + opnb + paratopeightid + pidstyleonea + clsb + semicolon + fn + nameninea + opnb + paratopnineid + pidstyleonea + clsb + semicolon + fn + nametena + opnb + paratoptenid + pidstyleonea + clsb + semicolon + fn + nameelevena + opnb + paratopelevenid + pidstyleonea + clsb + semicolon + "</script>" + "</head>" + "<body onload='showindow()'>" + alpha + paratopbegina + "To travel, chose the most favourable schedule for you and board, Thank you!" + paratopend + paratopbegin + topleftspanbegin + lefttopanchor + toplefttext + allanchorcloser + topleftspanend + topmiddlespanbegin + middletopanchor + middletoptext + allanchorcloser + topmiddlespanend + toprightspanbegin + righttopanchor + righttoptext + allanchorcloser + toprightspanend + paratopend + paratopbeginone + topleftspanbegin + lefttopanchor + toplefttext + allanchorcloser + topleftspanend + topmiddlespanbegin + middletopanchor + middletoptext + allanchorcloser + topmiddlespanend + toprightspanbegin + righttopanchor + righttoptext + allanchorcloser + toprightspanend + paratopend + paratopbegintwo + topleftspanbegin + lefttopanchor + toplefttext + allanchorcloser + topleftspanend + topmiddlespanbegin + middletopanchor + middletoptext + allanchorcloser + topmiddlespanend + toprightspanbegin + righttopanchor + righttoptext + allanchorcloser + toprightspanend + paratopend + paratopbeginthree + topleftspanbegin + lefttopanchor + toplefttext + allanchorcloser + topleftspanend + topmiddlespanbegin + middletopanchor + middletoptext + allanchorcloser + topmiddlespanend + toprightspanbegin + righttopanchor + righttoptext + allanchorcloser + toprightspanend + paratopend + paratopbeginfour + topleftspanbegin + lefttopanchor + toplefttext + allanchorcloser + topleftspanend + topmiddlespanbegin + middletopanchor + middletoptext + allanchorcloser + topmiddlespanend + toprightspanbegin + righttopanchor + righttoptext + allanchorcloser + toprightspanend + paratopend + paratopbeginfive + topleftspanbegin + lefttopanchor + toplefttext + allanchorcloser + topleftspanend + topmiddlespanbegin + middletopanchor + middletoptext + allanchorcloser + topmiddlespanend + toprightspanbegin + righttopanchor + righttoptext + allanchorcloser + toprightspanend + paratopend + paratopbeginsix + topleftspanbegin + lefttopanchor + toplefttext + allanchorcloser + topleftspanend + topmiddlespanbegin + middletopanchor + middletoptext + allanchorcloser + topmiddlespanend + toprightspanbegin + righttopanchor + righttoptext + allanchorcloser + toprightspanend + paratopend + paratopbeginseven + topleftspanbegin + lefttopanchor + toplefttext + allanchorcloser + topleftspanend + topmiddlespanbegin + middletopanchor + middletoptext + allanchorcloser + topmiddlespanend + toprightspanbegin + righttopanchor + righttoptext + allanchorcloser + toprightspanend + paratopend + paratopbegineight + topleftspanbegin + lefttopanchor + toplefttext + allanchorcloser + topleftspanend + topmiddlespanbegin + middletopanchor + middletoptext + allanchorcloser + topmiddlespanend + toprightspanbegin + righttopanchor + righttoptext + allanchorcloser + toprightspanend + paratopend + paratopbeginnine + topleftspanbegin + lefttopanchor + toplefttext + allanchorcloser + topleftspanend + topmiddlespanbegin + middletopanchor + middletoptext + allanchorcloser + topmiddlespanend + toprightspanbegin + righttopanchor + righttoptext + allanchorcloser + toprightspanend + paratopend + "<pre>" + "<p style='font-size: 20px;'>" + starts + headings + six + closeaspns + closeaspns + middles + headings + head + closeaspns + closeaspns + middles + headings + one + closeaspns + closeaspns + stops + headings + seven + closeaspns + closeaspns + starts + bodys + aa + closeaspns + closeaspns + middles + bodys + bb + closeaspns + closeaspns + middles + bodys + cc + closeaspns + closeaspns + stops + bodys + "<button onclick='showindow() || introheadoff() || showtoponeon() || showtoptwooff() || showtopthreeoff() || showtopfouroff() || showtopfiveoff() || showtopsixoff() || showtopsevenoff() || showtopeightoff() || showtopnineoff() || showtoptenoff()'>" + "<a href='#' style='text-decoration: none;' target='_parent'>" + dd + "</a>" + "</button>" + closeaspns+ closeaspns + starts + bodys + aaone + closeaspns + closeaspns + middles + bodys + bbone + closeaspns + closeaspns + middles + bodys + ccone + closeaspns + closeaspns + stops + bodys + "<button onclick='showindow() || showtoptwoon() || introheadoff() || showtoponeoff() || showtopthreeoff() || showtopfouroff() || showtopfiveoff() || showtopsixoff() || showtopsevenoff() || showtopeightoff() || showtopnineoff() || showtoptenoff()'>" + "<a href='#' style='text-decoration: none;' target='_parent'>" + ddone + "</a>" + "</button>" + closeaspns+ closeaspns + starts + bodys + aatwo + closeaspns + closeaspns + middles + bodys + bbtwo + closeaspns + closeaspns + middles + bodys + cctwo + closeaspns + closeaspns + stops + bodys + "<button onclick='showindow() || showtopthreeon() || introheadoff() || showtoponeoff() || showtoptwooff() || showtopfouroff() || showtopfiveoff() || showtopsixoff() || showtopsevenoff() || showtopeightoff() || showtopnineoff() || showtoptenoff()'>" + "<a href='#' style='text-decoration: none;' target='_parent'>" + ddtwo + "</a>" + "</button>" + closeaspns + closeaspns + starts + bodys + aathree + closeaspns + closeaspns + middles + bodys + bbthree + closeaspns + closeaspns + middles + bodys + ccthree + closeaspns + closeaspns + stops + bodys + "<button onclick='showindow() || showtopfouron() || introheadoff() || showtoponeoff() || showtoptwooff() || showtopthreeoff() || showtopfiveoff() || showtopsixoff() || showtopsevenoff() || showtopeightoff() || showtopnineoff() || showtoptenoff()'>" + "<a href='#' style='text-decoration: none;' target='_parent'>" + ddthree + "</a>" + "</button>" + closeaspns+ closeaspns + starts + bodys + aafour + closeaspns + closeaspns + middles + bodys + bbfour + closeaspns + closeaspns + middles + bodys + ccfour + closeaspns + closeaspns + stops + bodys + "<button onclick='showindow() || showtopfiveon() || introheadoff() || showtoponeoff() || showtoptwooff() || showtopthreeoff() || showtopfouroff() || showtopsixoff() || showtopsevenoff() || showtopeightoff() || showtopnineoff() || showtoptenoff()'>" + "<a href='#' style='text-decoration: none;' target='_parent'>" + ddfour + "</a>" + "</button>" + closeaspns+ closeaspns + starts + bodys + aafive + closeaspns + closeaspns + middles + bodys + bbfive + closeaspns + closeaspns + middles + bodys + ccfive + closeaspns + closeaspns + stops + bodys + "<button onclick='showindow() || showtopsixon() || introheadoff() || showtoponeoff() || showtoptwooff() || showtopthreeoff() || showtopfouroff() || showtopfiveoff() || showtopsevenoff() || showtopeightoff() || showtopnineoff() || showtoptenoff()'>" + "<a href='#' style='text-decoration: none;' target='_parent'>" + ddfive + "</a>" + "</button>" + closeaspns+ closeaspns + starts + bodys + aasix + closeaspns + closeaspns + middles + bodys + bbsix + closeaspns + closeaspns + middles + bodys + ccsix + closeaspns + closeaspns + stops + bodys + "<button onclick='showindow() || showtopsevenon() || introheadoff() || showtoponeoff() || showtoptwooff() || showtopthreeoff() || showtopfouroff() || showtopfiveoff() || showtopsixoff() || showtopeightoff() || showtopnineoff() || showtoptenoff()'>" + "<a href='#' style='text-decoration: none;' target='_parent'>" + ddsix + "</a>" + "</button>" + closeaspns+ closeaspns + starts + bodys + aaseven + closeaspns + closeaspns + middles + bodys + bbseven + closeaspns + closeaspns + middles + bodys + ccseven + closeaspns + closeaspns + stops + bodys + "<button onclick='showindow() || showtopeighton() || introheadoff() || showtoponeoff() || showtoptwooff() || showtopthreeoff() || showtopfouroff() || showtopfiveoff() || showtopsixoff() || showtopsevenoff() || showtopnineoff() || showtoptenoff()'>" + "<a href='#' style='text-decoration: none;' target='_parent'>" + ddseven + "</a>" + "</button>" + closeaspns+ closeaspns + starts + bodys + aaeight + closeaspns + closeaspns + middles + bodys + bbeight + closeaspns + closeaspns + middles + bodys + cceight + closeaspns + closeaspns + stops + bodys + "<button onclick='showindow() || showtopnineon() || introheadoff() || showtoponeoff() || showtoptwooff() || showtopthreeoff() || showtopfouroff() || showtopfiveoff() || showtopsixoff() || showtopsevenoff() || showtopeightoff() || showtoptenoff()'>" + "<a href='#' style='text-decoration: none;' target='_parent'>" + ddeight + "</a>" + "</button>" + closeaspns+ closeaspns + starts + bodys + aanine + closeaspns + closeaspns + middles + bodys + bbnine + closeaspns + closeaspns + middles + bodys + ccnine + closeaspns + closeaspns + stops + bodys + "<button onclick='showindow() || showtoptenon() || introheadoff() || showtoponeoff() || showtoptwooff() || showtopthreeoff() || showtopfouroff() || showtopfiveoff() || showtopsixoff() || showtopsevenoff() || showtopeightoff() || showtopnineoff()'>" + "<a href='#' style='text-decoration: none;' target='_parent'>" + ddnine + "</a>" + "</button>" + closeaspns+ closeaspns +"</p>" + "</pre>" + omega + "</body>" + "</html>";
	
	var paylinkid = "const payment = document.getElementById('paylink');";
	var gotpaylinkid = "payment.href = ";
	var paylinkida = "const payment = document.getElementById('paylinka');";
	
	var comma = ",";
	var fullstop = ".";
	
	var displaye = "<!DOCTYPE html>" + "<html lang='en'>" + "<head>" + "<meta charset='utf8'>" + "<meta name='viewport' content='width=device-width, initial-scale=1'/>" + "<title>" + "</title>" + "<script>" + fn + paypa + opnb + paylinkid + gotpaylinkid + "'" + paypalurl + "'" + semicolon + clsb + semicolon + "</script>" + "</head>" + "<body onload='showindow()'>" + alpha + "<div class='paymain' style='width: 100%; height: 600px; margin: 0; padding: 0; border: none; background-color: blue;'>" + "<div class='payinmain' style='margin: 0; padding: 0; border: none; width: 100%; height: 100%; background-color: green;'>" + "<div class='paytop' style='margin: 0; padding: 0; border: none; width: auto; height: 100%; background-color: pink;'>" + "<div class='payintop' style='width: auto; height: auto; margin: 0; padding: 0 5%; border: none; display:flex; justify-content:center; align-items:center; flex-direction:column; background-color: dodgerblue; font-family:arial; color:white; font-size: 20px;'>" + "<pre>" + paypalgreeting + comma + "\r" + "\r" + paypalclient + semicolon + "\r" + "\r" + paypalnote + fullstop + "\r" + "\r" + paypalinfo + "\r" + "\r" + "This Note is By Management" + paypalaccname + "\r" + "\r" + "<button onclick='paypal()'>" + "<a class='paylink' id='paylink' href='' style='background-color: ; padding: 0px; margin: 0; text-decoration: none;' target='_blank'>" + "OK" + "</a>" + "</button>" + "</div>" + "</div>" + "</pre>" + "</div>" + "</div>"  + omega + "</body>" + "</html>";
	
	var displayf = "<!DOCTYPE html>" + "<html lang='en'>" + "<head>" + "<meta charset='utf8'>" + "<meta name='viewport' content='width=device-width, initial-scale=1'/>" + "<title>" + "</title>" + "<script>" + fn + paypa + opnb + paylinkid + gotpaylinkid + "'" + pioneerurl + "'" + semicolon + clsb + semicolon + "</script>" + "</head>" + "<body onload='showindow()'>" + alpha + "<div class='paymain' style='width: 100%; height: 600px; margin: 0; padding: 0; border: none; background-color: blue;'>" + "<div class='payinmain' style='margin: 0; padding: 0; border: none; width: 100%; height: 100%; background-color: green;'>" + "<div class='paytop' style='margin: 0; padding: 0; border: none; width: auto; height: 100%; background-color: pink;'>" + "<div class='payintop' style='width: auto; height: auto; margin: 0; padding: 0 5%; border: none; display:flex; justify-content:center; align-items:center; flex-direction:column; background-color: dodgerblue; font-family:arial; color:white; font-size: 20px;'>" + "<pre>" + pioneergreeting + comma + "\r" + "\r" + pioneerclient + semicolon + "\r" + "\r" + pioneernote + fullstop + "\r" + "\r" + pioneerinfo + "\r" + "\r" + "This Note is By Management" + pioneeraccname + "\r" + "\r" + "<button onclick='paypal()'>" + "<a class='paylink' id='paylink' href='' style='background-color: ; padding: 0px; margin: 0; text-decoration: none;' target='_blank'>" + "OK" + "</a>" + "</button>" + "</div>" + "</div>" + "</pre>" + "</div>" + "</div>"  + omega + "</body>" + "</html>";
	
	var displayg = "<!DOCTYPE html>" + "<html lang='en'>" + "<head>" + "<meta charset='utf8'>" + "<meta name='viewport' content='width=device-width, initial-scale=1'/>" + "<title>" + "</title>" + "<script>" + fn + paypa + opnb + paylinkid + gotpaylinkid + "'" + mobilemoneyurl + "'" + semicolon + clsb + semicolon + "</script>" + "</head>" + "<body onload='showindow()'>" + alpha + "<div class='paymain' style='width: 100%; height: 600px; margin: 0; padding: 0; border: none; background-color: blue;'>" + "<div class='payinmain' style='margin: 0; padding: 0; border: none; width: 100%; height: 100%; background-color: green;'>" + "<div class='paytop' style='margin: 0; padding: 0; border: none; width: auto; height: 100%; background-color: pink;'>" + "<div class='payintop' style='width: auto; height: auto; margin: 0; padding: 0 5%; border: none; display:flex; justify-content:center; align-items:center; flex-direction:column; background-color: dodgerblue; font-family:arial; color:white; font-size: 20px;'>" + "<pre>" + mobilemoneygreeting + comma + "\r" + "\r" + mobilemoneyclient + semicolon + "\r" + "\r" + mobilemoneynote + fullstop + "\r" + "\r" + mobilemoneyinfo + "\r" + "\r" + "This Note is By Management" + mmmaccname + ammaccname + "\r" + "\r"  + "<a class='paylink' id='paylink' href='' style='background-color: ; padding: 0px; margin: 0; text-decoration: none;' target='_blank'>" + "<button onclick='paypal()' value='OK'>" + "OK" + "</button>" + "</a>" + "</div>" + "</div>" + "</pre>" + "</div>" + "</div>"  + omega + "</body>" + "</html>";
	
	

	
	var displayh = "<!DOCTYPE html>" + "<html lang='en'>" + "<head>" + "<meta charset='utf8'>" + "<meta name='viewport' content='width=device-width, initial-scale=1'/>" + "<title>" + "</title>" + "<script>" + fn + paypa + opnb + paylinkid + gotpaylinkid + "'" + mobilemoneyurlto + "'" + semicolon + clsb + semicolon + fn + paypaa + opnb + paylinkida + gotpaylinkid + "'" + mobilemoneyurltoa + "'" + semicolon + clsb + semicolon + "</script>" + "</head>" + "<body onload='showindow()'>" + alpha + "<div class='paymain' style='width: 100%; height: 600px; margin: 0; padding: 0; border: none; background-color: blue;'>" + "<div class='payinmain' style='margin: 0; padding: 0; border: none; width: 100%; height: 100%; background-color: green;'>" + "<div class='paytop' style='margin: 0; padding: 0; border: none; width: auto; height: 100%; background-color: pink;'>" + "<div class='payintop' style='width: auto; height: auto; margin: 0; padding: 0 5%; border: none; display:flex; justify-content:center; align-items:center; flex-direction:column; background-color: dodgerblue; font-family:arial; color:white; font-size: 20px; text-align: center;'>" + "Please Choose Your Favourate Mobile Money Provider" + "\r" + "\r" +  "<pre>" + "<span class='mmone' style=''>" + "<a href='' class='mmonea' style='background-color: #ffa587; border-radius: 20px/24px; padding: 5px 7px 5px 7px; text-decoration: none;' id='paylink'>" + "<button onclick='paypal()' style='background-color: rgba(255,255,255,0.1); border: none; outline: none;'>" + "AirtelMobileMoney" + "</button>" + "</a>" + "</span>" + "\r" + "\r" + "<span class='mmtwo' style=''>" + "<a href='' class='mmtwoa' style='background-color: yellow; border-radius: 20px/24px; padding: 5px 10px 5px 10px; text-decoration: none;' id='paylinka'>" + "<button onclick='paypala()' style='background-color: rgba(255,255,255,0.1); border: none; outline: none;'>" + "MTN MobileMoney" + "</button>" + "</a>" + "</span>" + "\r" + "\r" + "Click Atleast Any button Above to Pay" + "\r" + "\r" + "<button onclick='paypal()' disabled>" + "<a disabled class='paylink' id='paylink' href='' style='background-color: ; padding: 0px; margin: 0; text-decoration: none;' target='_blank'>" + "Thank You!" + "</a>" + "</button>" + "</div>" + "</div>" + "</pre>" + "</div>" + "</div>"  + omega + "</body>" + "</html>";
	
	
	  fs.writeFile(file, display, "utf8", (err) => {
	  	if (err) {
	  		throw err
	  	} else {
	  		
	    fs.readFile(file, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);""
			res.end();	
		} else {
			console.log(`Returning ${path}`);
		
			switch (path) {
				
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	  
	  	
	  	}
	  	
	  });
	
	//removed fs.readFile
	
	 fs.writeFile(filea, displaya, "utf8", (err) => {
	  	if (err) {
	  		throw err
	  	} else {
	  		
	    fs.readFile(filea, function(err, contenta) {
		  if (err) {
			console.log(`File not Found ${file}`);
			res.end();	
		} else {
			console.log(`Returning ${path}`);
		
			switch (path) {
				
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(contenta);	
			}
		}
	});	  
	  
	  	
	  	}
	  	
	  });
	
	//removed fs.readFile 
	
	fs.writeFile(filee, displaye, "utf8", (err) => {
	  	if (err) {
	  		throw err
	  	} else {
	  		
	    fs.readFile(filee, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);""
			res.end();	
		} else {
			console.log(`Returning ${path}`);
		
			switch (path) {
				
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	  
	  	
	  	}
	  	
	  });
	  
	  //removed fs.readFile 
	      
	      
	      fs.writeFile(filef, displayf, "utf8", (err) => {
	  	if (err) {
	  		throw err
	  	} else {
	  		
	    fs.readFile(filef, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);""
			res.end();	
		} else {
			console.log(`Returning ${path}`);
		
			switch (path) {
				
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	  
	  	
	  	}
	  	
	  });
	  
	  //removed fs.readFile 
	  
	  
	   fs.writeFile(fileg, displayg, "utf8", (err) => {
	  	if (err) {
	  		throw err
	  	} else {
	  		
	    fs.readFile(fileg, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);""
			res.end();	
		} else {
			console.log(`Returning ${path}`);
		
			switch (path) {
				
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	  
	  	
	  	}
	  	
	  });
	  
	  //removed fs.readFile
	  
	  fs.writeFile(fileh, displayh, "utf8", (err) => {
	  	if (err) {
	  		throw err
	  	} else {
	  		
	    fs.readFile(fileh, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);""
			res.end();	
		} else {
			console.log(`Returning ${path}`);
		
			switch (path) {
				
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	  
	  	
	  	}
	  	
	  });
	  
	  //removed fs.readFile 
	  
	   
	         
            res.end(form1);
        });
    } 
    else {
        res.end(form1);
    }
});
server.listen(3000, 'localhost', () => {
	console.log('Server 1 Listening at port 3000:');
});
//SERVER TWO STARTS:
const servertwo = http.createServer((req, res) => {	
	if (req.method === "POST") {	
		 collectRequestData(req, result => {
	let parsedURL = url.parse(req.url, true);
	let path = parsedURL.path.replace(/^\/+|\/+$/g, "");
	if (path == "") {
		path = "index.html";
	} 	      
	let file = __dirname + "/public/" + path;
	let filee =	__dirname + "/publice/" + path;
	    // 1. User Category data memory:
	var captureduser = "New user logged in at " 
	var suffixinfom = "with this details "
	
	
	 	
		//Login data memory:
	var msga = "<div>";
	var clientname = `${result.clientname}`;
	var clientphonenumber = `${result.clientphonenumber}`;
	var from = `${result.from}`;
	var to = `${result.to}`;
	var recieptno = `${result.recieptno}`;
	var currentDate = new Date();
	var msgb = "</div>";
	//Dashboard Data memory:
	var alpha = "<div>";
	var company = `${result.company}`;
	var adminpasscode = `${result.adminpasscode}`;
	var recieptemail = `${result.recieptemail}`;
	var d = `${result.cntdba}`;
	var e = `${result.pntdba}`;
	var f = `${result.lstdba}`;
	var omega = "</div>";
	var head = "Route:";
	var one = "Bus Brand:";
	var two = "Number Plate:";
	var three = "Conductor Name:";
	var four = "Phone Number";
	var five = "Leaving Status:";
	
	//conditional form rendering to user section
	
	  // 1. for user category
	  if (clientphonenumber == "" || recieptno == "") {
	  	
	  	/*fs.readFile(filee, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);
			res.end();	
		} else {
			switch (path) {
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	  */	
	  	
	  	res.writeHead(200, {"Content-type": "text/html"});
				res.write("<iframe src='http://localhost:3050/' height='630px' width='100%'>" + "</iframe>");
				res.end();
	  	
	  } else if (company == one && adminpasscode == two) { 
	  res.writeHead(200, {"Content-type": "text/html"});
	  
	  	res.end(htmlb);	
	  
	   
	   
	   }  else {
	  	
	 res.writeHead(200, {"Content-type": "text/html"});
	  	res.end(htmla);	
	  
	  };
	
	
	    //admin login
		/*if (comp == idNameOne && pswd == passwordOne) {
			console.log("Admin for" + " " + comp + " " + "bus company" + " " + "Logged in on:" + currentDate);
			res.statusCode = 200;
			res.end(form1);
		} else if (comp != idNameOne && pswd != passwordOne) {
			res.statusCode = 200;
			res.write("<h1 style='color:maroon; border: 1px red solid;'>To Change Updates, Login Below with Details :</h1>")
			res.end(login1);
		} else if (comp != idNameOne || pswd != passwordOne) {
			res.statusCode = 200;
			res.write("<h1 style='color:red; border: 1px red solid;'>One Wrong Login Details; Try again:</h1>")
			res.end(login1);
		} else {
			res.statusCode = 200;
			res.write("<h1 style='color:red; border: 1px red solid;'> To Update Dashboard Login Below with Details :</h1>")
			res.end(login1);
		}
           
           //content to user output section      
	  fs.writeFile(file, display, "utf8", (err) => {
	  	if (err) {
	  		throw err
	  	} else {
	    fs.readFile(file, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);
			res.end();	
		} else {
			switch (path) {
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	  	}
	  });//end fs.readFile */
	  console.log(captureduser + currentDate + suffixinfom);
	  console.log(result); 
				});
	} else {
			res.statusCode = 200;
			res.end(htmla);
		}
});
servertwo.listen(3010, 'localhost', () => {
	console.log('Server 2 Listening at port 3010:');
});

//SERVER THREE STARTS:
const serverthree = http.createServer((req, res) => {	
	if (req.method === "POST") {	
		 collectRequestData(req, result => {
	let parsedURL = url.parse(req.url, true);
	let path = parsedURL.path.replace(/^\/+|\/+$/g, "");
	if (path == "") {
		path = "index.html";
	} 	      
	let file = __dirname + "/public/" + path;
	let filee =	__dirname + "/publice/" + path;
	    // 1. User Category data memory:
	var captureduser = "New user logged in at " 
	var suffixinfom = "with this details "
	
	
	 	
		//Login data memory:
	var msga = "<div>";
	var clientname = `${result.clientname}`;
	var clientphonenumber = `${result.clientphonenumber}`;
	var from = `${result.from}`;
	var to = `${result.to}`;
	var recieptno = `${result.recieptno}`;
	var currentDate = new Date();
	var msgb = "</div>";
	//Dashboard Data memory:
	var alpha = "<div>";
	var company = `${result.company}`;
	var adminpasscode = `${result.adminpasscode}`;
	var recieptemail = `${result.recieptemail}`;
	var d = `${result.cntdba}`;
	var e = `${result.pntdba}`;
	var f = `${result.lstdba}`;
	var omega = "</div>";
	var head = "Route:";
	var one = "Bus Brand:";
	var two = "Number Plate:";
	var three = "Conductor Name:";
	var four = "Phone Number";
	var five = "Leaving Status:";
	
	//conditional form rendering to user section
	
	  // 1. for user category
	  if (clientphonenumber == "" || recieptno == "") {
	  	
	  	/*fs.readFile(filee, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);
			res.end();	
		} else {
			switch (path) {
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	  */	
	  	
	  	res.writeHead(200, {"Content-type": "text/html"});
				res.write("<iframe src='http://localhost:3060/' height='630px' width='100%'>" + "</iframe>");
				res.end();
	  	
	  } else if (company == one && adminpasscode == two) { 
	  res.writeHead(200, {"Content-type": "text/html"});
	  
	  	res.end(htmlb);	
	  
	   
	   
	   }  else {
	  	
	 res.writeHead(200, {"Content-type": "text/html"});
	  	res.end(htmla);	
	  
	  };
	
	
	    //admin login
		/*if (comp == idNameOne && pswd == passwordOne) {
			console.log("Admin for" + " " + comp + " " + "bus company" + " " + "Logged in on:" + currentDate);
			res.statusCode = 200;
			res.end(form1);
		} else if (comp != idNameOne && pswd != passwordOne) {
			res.statusCode = 200;
			res.write("<h1 style='color:maroon; border: 1px red solid;'>To Change Updates, Login Below with Details :</h1>")
			res.end(login1);
		} else if (comp != idNameOne || pswd != passwordOne) {
			res.statusCode = 200;
			res.write("<h1 style='color:red; border: 1px red solid;'>One Wrong Login Details; Try again:</h1>")
			res.end(login1);
		} else {
			res.statusCode = 200;
			res.write("<h1 style='color:red; border: 1px red solid;'> To Update Dashboard Login Below with Details :</h1>")
			res.end(login1);
		}
           
           //content to user output section      
	  fs.writeFile(file, display, "utf8", (err) => {
	  	if (err) {
	  		throw err
	  	} else {
	    fs.readFile(file, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);
			res.end();	
		} else {
			switch (path) {
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	  	}
	  });//end fs.readFile */
	  console.log(captureduser + currentDate + suffixinfom);
	  console.log(result); 
				});
	} else {
			res.statusCode = 200;
			res.end(htmla);
		}
});
serverthree.listen(3020, 'localhost', () => {
	console.log('Server 3 Listening at port 3020:');
});

//SERVER FOUR STARTS:
const serverfour = http.createServer((req, res) => {	
	if (req.method === "POST") {	
		 collectRequestData(req, result => {
	let parsedURL = url.parse(req.url, true);
	let path = parsedURL.path.replace(/^\/+|\/+$/g, "");
	if (path == "") {
		path = "index.html";
	} 	      
	let file = __dirname + "/public/" + path;
	let filee =	__dirname + "/publice/" + path;
	    // 1. User Category data memory:
	var captureduser = "New user logged in at " 
	var suffixinfom = "with this details "
	
	
	 	
		//Login data memory:
	var msga = "<div>";
	var clientname = `${result.clientname}`;
	var clientphonenumber = `${result.clientphonenumber}`;
	var from = `${result.from}`;
	var to = `${result.to}`;
	var recieptno = `${result.recieptno}`;
	var currentDate = new Date();
	var msgb = "</div>";
	//Dashboard Data memory:
	var alpha = "<div>";
	var company = `${result.company}`;
	var adminpasscode = `${result.adminpasscode}`;
	var recieptemail = `${result.recieptemail}`;
	var d = `${result.cntdba}`;
	var e = `${result.pntdba}`;
	var f = `${result.lstdba}`;
	var omega = "</div>";
	var head = "Route:";
	var one = "Bus Brand:";
	var two = "Number Plate:";
	var three = "Conductor Name:";
	var four = "Phone Number";
	var five = "Leaving Status:";
	
	//conditional form rendering to user section
	
	  // 1. for user category
	  if (clientphonenumber == "" || recieptno == "") {
	  	
	  	/*fs.readFile(filee, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);
			res.end();	
		} else {
			switch (path) {
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	  */	
	  	
	  	res.writeHead(200, {"Content-type": "text/html"});
				res.write("<iframe src='http://localhost:3070/' height='630px' width='100%'>" + "</iframe>");
				res.end();
	  	
	  } else if (company == one && adminpasscode == two) { 
	  res.writeHead(200, {"Content-type": "text/html"});
	  
	  	res.end(htmlb);	
	  
	   
	   
	   }  else {
	  	
	 res.writeHead(200, {"Content-type": "text/html"});
	  	res.end(htmla);	
	  
	  };
	
	
	    //admin login
		/*if (comp == idNameOne && pswd == passwordOne) {
			console.log("Admin for" + " " + comp + " " + "bus company" + " " + "Logged in on:" + currentDate);
			res.statusCode = 200;
			res.end(form1);
		} else if (comp != idNameOne && pswd != passwordOne) {
			res.statusCode = 200;
			res.write("<h1 style='color:maroon; border: 1px red solid;'>To Change Updates, Login Below with Details :</h1>")
			res.end(login1);
		} else if (comp != idNameOne || pswd != passwordOne) {
			res.statusCode = 200;
			res.write("<h1 style='color:red; border: 1px red solid;'>One Wrong Login Details; Try again:</h1>")
			res.end(login1);
		} else {
			res.statusCode = 200;
			res.write("<h1 style='color:red; border: 1px red solid;'> To Update Dashboard Login Below with Details :</h1>")
			res.end(login1);
		}
           
           //content to user output section      
	  fs.writeFile(file, display, "utf8", (err) => {
	  	if (err) {
	  		throw err
	  	} else {
	    fs.readFile(file, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);
			res.end();	
		} else {
			switch (path) {
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	  	}
	  });//end fs.readFile */
	  console.log(captureduser + currentDate + suffixinfom);
	  console.log(result); 
				});
	} else {
			res.statusCode = 200;
			res.end(htmla);
		}
});
serverfour.listen(3030, 'localhost', () => {
	console.log('Server 4 Listening at port 3030:');
});



//SERVER 5 STARTED:

const serverfive = http.createServer((req, res) => {	
	
	let parsedURL = url.parse(req.url, true);
	let path = parsedURL.path.replace(/^\/+|\/+$/g, "");
	if (path == "") {
		path = "index.html";
	} 	      
	let file = __dirname + "/public/" + path;
	let filee =	__dirname + "/publice/" + path;

fs.readFile(filee, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);""
			res.end();	
		} else {
			console.log(`Returning ${path}`);
		
			switch (path) {
				
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	
	
	});
	  
	 serverfive.listen(3050, 'localhost', () => {
	console.log('Server 5 Listening at port 3050:');
});
 
 //SERVER 6 STARTED:

const serversix = http.createServer((req, res) => {	
	
	let parsedURL = url.parse(req.url, true);
	let path = parsedURL.path.replace(/^\/+|\/+$/g, "");
	if (path == "") {
		path = "index.html";
	} 	      
	let file = __dirname + "/public/" + path;
	let filef =	__dirname + "/publicf/" + path;

fs.readFile(filef, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);""
			res.end();	
		} else {
			console.log(`Returning ${path}`);
		
			switch (path) {
				
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	
	
	});
	  
	 serversix.listen(3060, 'localhost', () => {
	console.log('Server 6 Listening at port 3060:');
});
 
  //SERVER 7 STARTED:

const serverseven = http.createServer((req, res) => {	
	
	let parsedURL = url.parse(req.url, true);
	let path = parsedURL.path.replace(/^\/+|\/+$/g, "");
	if (path == "") {
		path = "index.html";
	} 	      
	let file = __dirname + "/public/" + path;
	let fileg =	__dirname + "/publicg/" + path;

fs.readFile(fileg, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);""
			res.end();	
		} else {
			console.log(`Returning ${path}`);
		
			switch (path) {
				
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	
	
	});
	  
	 serverseven.listen(3070, 'localhost', () => {
	console.log('Server 7 Listening at port 3070:');
});
 
//SERVER 8 STARTED:

const servereight = http.createServer((req, res) => {	
	
	let parsedURL = url.parse(req.url, true);
	let path = parsedURL.path.replace(/^\/+|\/+$/g, "");
	if (path == "") {
		path = "index.html";
	} 	      
	let file = __dirname + "/public/" + path;
	let fileh =	__dirname + "/publich/" + path;

fs.readFile(fileh, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);""
			res.end();	
		} else {
			console.log(`Returning ${path}`);
		
			switch (path) {
				
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	
	
	});
	  
	 servereight.listen(3080, 'localhost', () => {
	console.log('Server 8 Listening at port 3080:');
});
  
  
  //SERVER NINE STARTS:
const servernine = http.createServer((req, res) => {	
	if (req.method === "POST") {	
		 collectRequestData(req, result => {
	let parsedURL = url.parse(req.url, true);
	let path = parsedURL.path.replace(/^\/+|\/+$/g, "");
	if (path == "") {
		path = "index.html";
	} 	      
	let file = __dirname + "/public/" + path;
	let filee =	__dirname + "/publice/" + path;
	    // 1. User Category data memory:
	var captureduser = "New user logged in at " 
	var suffixinfom = "with this details "
		//Login data memory:
	var msga = "<div>";
	var clientname = `${result.clientname}`;
	var clientphonenumber = `${result.clientphonenumber}`;
	var from = `${result.from}`;
	var to = `${result.to}`;
	var recieptno = `${result.recieptno}`;
	var currentDate = new Date();
	var msgb = "</div>";
	//Dashboard Data memory:
	var alpha = "<div>";
	var email = `${result.newUserEmail}`;
	var phone = `${result.newUserPhoneNumber}`;
	var recieptemail = `${result.recieptemail}`;
	var d = `${result.cntdba}`;
	var e = `${result.pntdba}`;
	var f = `${result.lstdba}`;
	var omega = "</div>";
	var head = "Route:";
	var one = "Bus Brand:";
	var two = "Number Plate:";
	var three = "Conductor Name:";
	var four = "Phone Number";
	var five = "Leaving Status:";
	//conditional form rendering to user section
	  // 1. for user category
	  if (email != "" || phone != "") {
	  	res.writeHead(200, {"Content-type": "text/html"});
				res.write("<iframe src='http://localhost:4000/' height='630px' width='100%' >" + "</iframe>");
				res.end();
	  } else {
	 res.writeHead(200, {"Content-type": "text/html"});
	  	res.end("Blocked Access! Start Again");	
	  };
	  console.log(captureduser + currentDate + suffixinfom);
	  console.log(result); 
				});
	} else {
			res.statusCode = 200;
			res.end(logina);
		}
});
servernine.listen(3090, 'localhost', () => {
	console.log('Server 9 Listening at port 3090:');
});
	
//SERVER 10 STARTED:

const serverten = http.createServer((req, res) => {	
	
	let parsedURL = url.parse(req.url, true);
	let path = parsedURL.path.replace(/^\/+|\/+$/g, "");
	if (path == "") {
		path = "index.html";
	} 	      
	let file = __dirname + "/public/" + path;
	let filebegin =	__dirname + "/publicbegin/" + path;

fs.readFile(filebegin, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);""
			res.end();	
		} else {
			console.log(`Returning ${path}`);
		
			switch (path) {
				
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	
	
	});
	  
	 serverten.listen(4000, 'localhost', () => {
	console.log('Server 10 Listening at port 4000:');
});
	
	
//SERVER 11 STARTED:

const servereleven = http.createServer((req, res) => {	
	
	let parsedURL = url.parse(req.url, true);
	let path = parsedURL.path.replace(/^\/+|\/+$/g, "");
	if (path == "") {
		path = "index.html";
	} 	      
	let file = __dirname + "/public/" + path;
	let filee =	__dirname + "/publice/" + path;

fs.readFile(filee, function(err, content) {
		  if (err) {
			console.log(`File not Found ${file}`);""
			res.end();	
		} else {
			console.log(`Returning ${path}`);
		
			switch (path) {
				
				case "index.html":
				 res.writeHead(200, {"Content-type": "text/html"});
				res.end(content);	
			}
		}
	});	  
	
	
	});
	  
	 servereleven.listen(4010, 'localhost', () => {
	console.log('Server 11 Listening at port 4010:');
});	  

//processor function
function collectRequestData(request, callback) {
    const FORM_URLENCODED = 'application/x-www-form-urlencoded';
    const otherct = 'text/html';
    if(request.headers['content-type'] === FORM_URLENCODED || res.setHeader("X-Content-Type-Options", "nosiniff")) {
        let body = '';
        request.on('data', chunk => {
            body += chunk.toString();
        });
        request.on('end', () => {
            callback(parse(body));
        });
    }
    else {
        callback(null);
    }
}